<?php
if(!defined('ABSPATH')) { exit; } // 直接URLを入力してのアクセスを防ぐ

if (!class_exists( 'SimpleComments_Nonce' ) ) {
  class SimpleComments_Nonce {
    private int $nonce;
    private DateTime $createTime;
    public function __construct() {
      $this->nonce = random_int(PHP_INT_MIN, PHP_INT_MAX);
      $this->createTime = new DateTime();
    }
    public function get_nonce() {
      return $this->nonce;
    }
      
    public function is_match(?int $nonce) {
        if (is_null($nonce)) {
            return false;
        }
        return $this->nonce == $nonce;
    }
    public function is_earlier(?DateTime $than) {
      if (is_null($than)) {
          return false;
      }
      return $this->createTime < $than;
    }
  }
}


if (!class_exists( 'SimpleComments_NonceManager' ) ) {
  class SimpleComments_NonceManager {
    public static $MAP = array();
    static public function regist(string $ip, SimpleComments_Nonce $nonce) {
        self::$MAP[$ip] = $nonce;
    }
    static public function remove(string $ip) {
      if(!array_key_exists($ip, self::$MAP)) {
          return null;
      }
      $nonce = self::$MAP[$ip];
      unset(self::$MAP[$ip]);
      return $nonce;
    }
    
    // 指定した日時より前のnonceを削除
    static public function remove_earier(DateTime $than) {
        foreach(self::$MAP as $ip=>$nonce) {
            if($nonce->is_earlier($than)) {
                unset(self::$MAP[$ip]);
            }
        };
    }
  }
}

// 使用例
// $time = new DateTime();
// SimpleComments_NonceManager::regist('192', new SimpleComments_Nonce('19two'));
// $time = new DateTime();
// SimpleComments_NonceManager::remove_earier($time);
// echo is_null(SimpleComments_NonceManager::remove('192')) ? 'null' : 'exist';





